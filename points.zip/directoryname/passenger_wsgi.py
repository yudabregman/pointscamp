"from pythonapp import MyApp as application" 
